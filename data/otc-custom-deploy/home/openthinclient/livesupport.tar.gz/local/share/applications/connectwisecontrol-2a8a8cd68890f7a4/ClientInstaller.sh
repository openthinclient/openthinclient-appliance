#!/bin/sh
packageName='connectwisecontrol-2a8a8cd68890f7a4'
instanceUrlScheme='sc-2a8a8cd68890f7a4'
applicationTitle='levigo livesupport Client'
clientLauncherShellScriptFileName='ClientLauncher.sh'
applicationIconFileName='ApplicationIcon32.png'

userLevelApplicationsDirectory="$HOME/.local/share/applications"
clientInstallationDirectory="$userLevelApplicationsDirectory/$packageName"
clientDesktopFilePath="$userLevelApplicationsDirectory/$packageName.desktop"

mkdir -p "$clientInstallationDirectory"
ls -1 "/tmp/$packageName" | xargs -I{} mv -f "/tmp/$packageName/{}" "$clientInstallationDirectory"

echo "[Desktop Entry]" > "$clientDesktopFilePath"
echo "Type=Application" >> "$clientDesktopFilePath"
echo "MimeType=x-scheme-handler/$instanceUrlScheme" >> "$clientDesktopFilePath"
echo "Name=$applicationTitle" >> "$clientDesktopFilePath"
echo "Exec=$clientInstallationDirectory/$clientLauncherShellScriptFileName %u" >> "$clientDesktopFilePath"
echo "Icon=$clientInstallationDirectory/$applicationIconFileName" >> "$clientDesktopFilePath"

update-desktop-database "$userLevelApplicationsDirectory"
xdg-mime default "$clientDesktopFilePath" x-scheme-handler/"$instanceUrlScheme"

sh "$clientInstallationDirectory/$clientLauncherShellScriptFileName"

exit 0
