#!/bin/sh
packageName='connectwisecontrol-2a8a8cd68890f7a4'

userLevelApplicationsDirectory="$HOME/.local/share/applications"
clientInstallationDirectory="$userLevelApplicationsDirectory/$packageName"
clientDesktopFilePath="$userLevelApplicationsDirectory/$packageName.desktop"

rm "$clientDesktopFilePath"
update-desktop-database "$userLevelApplicationsDirectory"

rm -r "$clientInstallationDirectory"

exit 0
